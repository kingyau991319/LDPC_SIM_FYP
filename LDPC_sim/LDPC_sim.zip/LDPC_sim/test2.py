import numpy as np
import numba

def gf2elim(M):

    m,n = M.shape

    i=0
    j=0

    while i < m and j < n:
        # find value and index of largest element in remainder of column j
        k = np.argmax(M[i:, j]) +i

        # swap rows
        #M[[k, i]] = M[[i, k]] this doesn't work with numba
        temp = np.copy(M[k])
        M[k] = M[i]
        M[i] = temp


        aijn = M[i, j:]

        col = np.copy(M[:, j]) #make a copy otherwise M will be directly affected

        col[i] = 0 #avoid xoring pivot row with itself

        flip = np.outer(col, aijn)

        M[:, j:] = M[:, j:] ^ flip

        i +=1
        j +=1

    return M

f = open("test_code","r")

str = f.read()
str = str.split()
str = np.array(str)
str_len = len(str)
input_num = str.astype(np.int)

xlen = input_num[0]
ylen = input_num[1]
code_rate = ylen / xlen
wc = input_num[2]
wr = input_num[3]
wc_num = input_num[xlen+4:xlen+ylen+4]

lower_bound_of_array = str_len - np.sum(wc_num)

input_num = input_num[lower_bound_of_array:]
parity_check_matrix = np.zeros((ylen,xlen))
x_index_index = 0

for y_axis in range(ylen):
    for x_axis in range(wc_num[y_axis]):
        x_index = input_num[x_index_index] - 1
        parity_check_matrix[y_axis][x_index] = 1
        x_index_index = x_index_index + 1

# for y_axis in range(ylen):
#     for x_axis in range(ylen):
#         parity_check_matrix[y_axis][ylen+x_axis] = 0
#     parity_check_matrix[y_axis][ylen+y_axis] = 1



# for k in range(100000):


# parity_check_matrix_trans = parity_check_matrix[:ylen,:ylen].copy().transpose()
        
# generator_matrix = np.zeros((ylen,xlen))
# for y_axis in range(ylen):
#     for x_axis in range(xlen):
#         if x_axis >= ylen:
#             generator_matrix[y_axis][x_axis] = parity_check_matrix_trans[y_axis][x_axis-ylen]
#     generator_matrix[y_axis][y_axis] = 1

# generator_matrix_to_list = generator_matrix.tolist()

# print()

# for y_axis in range(ylen):
#     for x_axis in range(xlen):
#         print(int(generator_matrix_to_list[y_axis][x_axis]),end='')
#     print()


# @numba.jit(nopython=True, parallel=True) #parallel speeds up computation only over very large matrices
# M is a mxn matrix binary matrix 
# all elements in M should be uint8 

parity_check_matrix = parity_check_matrix.astype(np.uint8)
parity_check_matrix_copy = np.zeros((ylen,xlen))
generator_matrix = np.zeros((ylen,xlen))

# what i need to do first
# 1. change the parity check matrix
# 2. apply gf2elim
# 3. transpose and make generator matrix

for y_axis in range(ylen):
    for x_axis in range(ylen):
        parity_check_matrix_copy[y_axis][x_axis] = int(parity_check_matrix[y_axis][x_axis+ylen])
        parity_check_matrix_copy[y_axis][x_axis+ylen] = int(parity_check_matrix[y_axis][x_axis])

parity_check_matrix_copy = parity_check_matrix_copy.astype(np.uint8)

# for y_axis in range(ylen):
#     for x_axis in range(xlen):
#         print(parity_check_matrix_copy[y_axis][x_axis],end='')
#     print()

M = gf2elim(parity_check_matrix_copy)

M2 = np.zeros((ylen,ylen))

for y_axis in range(ylen):
    for x_axis in range(ylen):
        M2[y_axis][x_axis] = M[y_axis][x_axis+ylen]

M2 = np.transpose(M2)
M2 = M2.astype(np.uint8)

for y_axis in range(ylen):
    for x_axis in range(ylen):
        print(M2[y_axis][x_axis],end='')
    print()

for y_axis in range(ylen):
    generator_matrix[y_axis][y_axis] = 1
    for x_axis in range(ylen):
        generator_matrix[y_axis][x_axis+ylen] = int(M2[y_axis][x_axis+ylen])

# generator_matrix = generator_matrix.astype(np.uint8)

# for y_axis in range(ylen):
#     for x_axis in range(xlen):
#         print(generator_matrix[y_axis][x_axis],end='')
#     print()
