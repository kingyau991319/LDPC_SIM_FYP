import numpy as np
from numpy.linalg import matrix_rank
import pandas as pd
import matplotlib.pyplot as plt 
from scipy import special
import warnings

def plot_SNR_graph(name,name1):

    warnings.filterwarnings('ignore')

    df = pd.read_csv("sim_result.csv")
    filter = (df["LDPC_code"] == name)

    df1 = df[filter]
    df1 = df1[['LDPC_code','SNRbDB','average_probaility_error','noise_set']]
    df1 = df1.sort_values(by=['SNRbDB'])
    x_axis_value = df1['SNRbDB'].to_numpy()
    x_axis_value = (10 ** (x_axis_value / 10))
    y_axis_value = df1['average_probaility_error'].to_numpy()

    filter2 = (df["LDPC_code"] == name1)
    df2 = df[filter2]
    df2 = df2[['LDPC_code','SNRbDB','average_probaility_error','noise_set']]
    df2 = df2.sort_values(by=['SNRbDB'])
    x_axis_value2 = df2['SNRbDB'].to_numpy()
    y_axis_value2 = df2['average_probaility_error'].to_numpy()


    x_xaxis_plot = np.linspace(0,12,16)

    fig, ax = plt.subplots()
    x_noise_set= np.linspace(0,15,100)

    y_function = x_noise_set.copy()
    k = np.sqrt(2 * (10 ** (x_noise_set / 10) ))
    y_function = 0.5 * special.erfc(k/np.sqrt(2))

    ax.set_yscale('log')

    plt.xlabel("E$_{b}$/N$_{0}$ (dB)")
    # plt.xticks(x_xaxis_plot)
    plt.ylabel("bit error rate(BER)")
    plt.ylim((10**-6,1))

    plt.grid(True,linestyle='-.')

    plt.scatter(x_axis_value,y_axis_value)
    plt.plot(x_axis_value,y_axis_value,label=name)

    plt.scatter(x_axis_value2,y_axis_value2)
    plt.plot(x_axis_value2,y_axis_value2,label=name1)
    # plt.axis('tight') 
    plt.margins(x=0)

    # Q function with ecnoding plot
    plt.plot(x_noise_set,y_function,label="uncoded data transmission")
    plt.legend()
    plt.show()

plot_SNR_graph("MacKeyCodeTest","MacKeyCode_204.33.484")